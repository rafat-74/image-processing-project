import boto3
from PIL import Image
import io
import os

s3 = boto3.client('s3')

def lambda_handler(event, context):
    # جلب اسم الباكت والملف من الحدث
    source_bucket = event['Records'][0]['s3']['bucket']['name']
    image_key = event['Records'][0]['s3']['object']['key']
    destination_bucket = os.environ['DEST_BUCKET']

    # تحميل الصورة الأصلية من S3
    original_image = s3.get_object(Bucket=source_bucket, Key=image_key)
    image_content = original_image['Body'].read()

    # معالجة الصورة (تغيير الحجم)
    image = Image.open(io.BytesIO(image_content))
    image = image.resize((800, 600))

    # حفظ الصورة الجديدة في الذاكرة
    buffer = io.BytesIO()
    image.save(buffer, 'JPEG')
    buffer.seek(0)

    # رفع الصورة الجديدة إلى S3
    s3.put_object(Bucket=destination_bucket, Key=image_key, Body=buffer, ContentType='image/jpeg')

    return {
        'statusCode': 200,
        'body': f'Image {image_key} resized and uploaded to {destination_bucket}'
    }
